t = '8.34234,48.23424'
ts = t.split(',')
print(ts[0])