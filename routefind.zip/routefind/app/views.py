from django.shortcuts import render
import openrouteservice

# Create your views here.

def index(request):
    #print(request.method)
    #print(request.POST.get('start'))
    routes = None
    if request.method == 'POST':
        start = request.POST.get('start')
        end = request.POST.get('end')
        starts = start.split(',')
        ends = end.split(',')
        coords = ((starts[0],starts[1]),(ends[0],ends[1]))
        client = openrouteservice.Client(key='5b3ce3597851110001cf6248985ab32933474ddd925a3906b03a87ba') # Specify your personal API key
        routes = client.directions(coords, profile='cycling-regular', optimize_waypoints=True)
    # 5b3ce3597851110001cf6248985ab32933474ddd925a3906b03a87ba
    return render(request,'index.html',{"data":routes})
